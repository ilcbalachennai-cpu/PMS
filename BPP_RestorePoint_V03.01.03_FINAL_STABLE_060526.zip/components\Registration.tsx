
import React, { useState, useEffect } from 'react';
import {
    Building2,
    ShieldCheck,
    UserPlus,
    CheckCircle2,
    ArrowRight,
    ArrowLeft,
    ShieldAlert,
    Mail,
    Phone,
    Lock,
    Eye,
    EyeOff,
    IndianRupee,
    Database,
    Upload,
    Loader2,
    UserCircle,
    Power,
    BadgeCheck,
    RotateCw,
    KeyRound
} from 'lucide-react';
import { CompanyProfile, StatutoryConfig, User } from '../types';
import { INITIAL_COMPANY_PROFILE, INITIAL_STATUTORY_CONFIG, BRAND_CONFIG } from '../constants';
import { activateFullLicense, registerTrial, isValidKeyFormat, updateCloudPassword, sendRegistrationOTP, verifyRegistrationOTP, getStoredLicense } from '../services/licenseService';
import CryptoJS from 'crypto-js';

interface RegistrationProps {
    onComplete: (data: {
        companyProfile: CompanyProfile;
        statutoryConfig: StatutoryConfig;
        adminUser: User;
    }) => void;
    onRestore: () => void;
    showAlert?: (type: 'success' | 'error' | 'info' | 'warning' | 'confirm', title: string, message: string, onConfirm?: () => void) => void;
    isResetMode?: boolean;
    onSystemRepair?: () => void;
    isNewCompany?: boolean;
    activeCompanyId?: string;
}

const Registration: React.FC<RegistrationProps> = ({ onComplete, onRestore, showAlert, isResetMode, onSystemRepair, isNewCompany, activeCompanyId }) => {
    const [step, setStep] = useState(1);
    const [userName, setUserName] = useState('');
    const [userID, setUserID] = useState('');
    const [licenseKey, setLicenseKey] = useState('');
    const [regEmail, setRegEmail] = useState('');
    const [regMobile, setRegMobile] = useState('');
    const [showKeyInput, setShowKeyInput] = useState(false);
    const [_profile, setProfile] = useState<CompanyProfile>(INITIAL_COMPANY_PROFILE);
    const [_config] = useState<StatutoryConfig>(INITIAL_STATUTORY_CONFIG);
    const [adminPassword, setAdminPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [isTrialUser, setIsTrialUser] = useState(false);

    // Reset profile for new company mode
    useEffect(() => {
        if (isNewCompany) {
            const license = getStoredLicense();
            if (license) {
                setUserID(license.userID || '');
                setUserName(license.userName || '');
                setRegEmail(license.registeredTo || '');
                setRegMobile(license.registeredMobile || '');
                setIsFetchedIdentity(true);
                setEmailVerifyState('verified');
                setStep(4); // Skip to Choice (Restore vs Manual)
            } else {
                setProfile(INITIAL_COMPANY_PROFILE);
            }
        }
    }, [isNewCompany]);

    // Email OTP Verification State
    type EmailVerifyState = 'idle' | 'sending' | 'otp_pending' | 'verifying' | 'verified';
    const [emailVerifyState, setEmailVerifyState] = useState<EmailVerifyState>('idle');
    const [regOTP, setRegOTP] = useState('');
    const [emailVerifyMsg, setEmailVerifyMsg] = useState('');
    const otpInputRef = React.useRef<HTMLInputElement>(null);

    // Restore State
    const [showRestoreFields, setShowRestoreFields] = useState(false);
    const [showCompanyInput, setShowCompanyInput] = useState(false);
    const [companyName, setCompanyName] = useState('');
    const [companyPass, setCompanyPass] = useState('');
    const [showPin, setShowPin] = useState(false);
    const [encryptionKey, setEncryptionKey] = useState('');

    const [isProcessing, setIsProcessing] = useState(false);
    const [isFetchedIdentity, setIsFetchedIdentity] = useState(false);
    const backupFileRef = React.useRef<HTMLInputElement>(null);
    const passwordRef = React.useRef<HTMLInputElement>(null);
    const decryptPasswordRef = React.useRef<HTMLInputElement>(null);

    const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
    const containerRef = React.useRef<HTMLDivElement>(null);

    // Reset email verification when the email address is changed
    useEffect(() => {
        if (emailVerifyState !== 'idle') {
            setEmailVerifyState('idle');
            setRegOTP('');
            setEmailVerifyMsg('');
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [regEmail]);

    // Clear error when inputs change
    useEffect(() => {
        setError('');
    }, [userName, userID, regEmail, regMobile, adminPassword, confirmPassword, encryptionKey]);

    const handleSendEmailOTP = async () => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!regEmail || !emailRegex.test(regEmail)) {
            setEmailVerifyMsg('Please enter a valid email address first.');
            return;
        }
        setEmailVerifyState('sending');
        setEmailVerifyMsg('');
        setRegOTP('');
        const result = await sendRegistrationOTP(regEmail);
        if (result.success) {
            setEmailVerifyState('otp_pending');
            setEmailVerifyMsg('OTP sent! Check your inbox and enter the 6-digit code below.');
            setTimeout(() => otpInputRef.current?.focus(), 100);
        } else {
            setEmailVerifyState('idle');
            setEmailVerifyMsg(result.message || 'Failed to send OTP. Please try again.');
        }
    };

    const handleVerifyEmailOTP = async () => {
        if (regOTP.length !== 6) {
            setEmailVerifyMsg('Please enter the complete 6-digit OTP.');
            return;
        }
        setEmailVerifyState('verifying');
        setEmailVerifyMsg('');
        const result = await verifyRegistrationOTP(regEmail, regMobile, regOTP);
        if (result.success) {
            setEmailVerifyState('verified');
            setEmailVerifyMsg('Identity verified successfully!');
            // Reveal and lock the UserID/Name if returned from cloud
            if (result.data) {
                if (result.data.userID) {
                    setUserID(result.data.userID);
                    setIsFetchedIdentity(true);
                }
                if (result.data.userName) setUserName(result.data.userName);
                if (result.data.isTrial) setIsTrialUser(true);
            } else {
                setIsFetchedIdentity(false);
                setIsTrialUser(false);
            }
        } else {
            setEmailVerifyState('otp_pending');
            setEmailVerifyMsg(result.message || 'Verification Failed. Please try again.');
        }
    };

    // Auto-focus on step change
    useEffect(() => {
        const timer = setTimeout(() => {
            if (step === 1 && nameInputRef.current) {
                nameInputRef.current.focus();
            } else if (step === 2 && passwordRef.current) {
                passwordRef.current.focus();
            }
        }, 50); // Immediate focus
        return () => clearTimeout(timer);
    }, [step]);

    const nameInputRef = React.useRef<HTMLInputElement>(null);

    const nextStep = async () => {
        if (step === 1) {
            if (emailVerifyState !== 'verified') {
                setError('Please verify your email with OTP before proceeding.');
                return;
            }
        }
        
        if (step === 2) {
            if (!userName) {
                setError('Full Name is required.');
                return;
            }
            const idRegex = /^[A-Z0-9]{5,12}$/;
            if (!userID) {
                setError('User ID is required.');
                return;
            }
            if (!idRegex.test(userID)) {
                setError('User ID must be 5-12 alphanumeric characters with no spaces.');
                return;
            }

            // --- V02.02.21: Password Validation ---
            const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{9,}$/;

            if (!adminPassword) {
                setError('Administrator password is required.');
                return;
            }
            if (adminPassword.length < 9) {
                setError('Password must be at least 9 characters long.');
                return;
            }
            if (!passwordRegex.test(adminPassword)) {
                setError('Password requirement not met: One uppercase, one lowercase, one number, and one special character are required.');
                return;
            }
            if (adminPassword !== confirmPassword) {
                setError('Passwords do not match.');
                return;
            }

            setIsProcessing(true);
            let result;

            if (licenseKey) {
                // Attempt Full License Activation
                if (!isValidKeyFormat(licenseKey)) {
                    setError('Please enter a valid 16-digit license key.');
                    setIsProcessing(false);
                    return;
                }
                result = await activateFullLicense(userName, userID, licenseKey, regEmail, regMobile, adminPassword);
            } else {
                // Attempt Trial Registration
                result = await registerTrial(userName, userID, regEmail, regMobile, adminPassword);
            }

            setIsProcessing(false);

            if (!result.success) {
                setError(result.message || 'Activation Failed.');
                if (result.message?.includes('Unauthorised')) {
                    setTimeout(() => {
                        // @ts-ignore
                        if (window.electronAPI) window.electronAPI.closeApp();
                    }, 3000);
                }
                return;
            }

            if (showAlert && result.message) {
                const isRestoration = result.message.includes('History Found') || result.message.includes('Trial Restored');
                showAlert(
                    isRestoration ? 'info' : 'success', 
                    isRestoration ? 'Identity Verified' : 'Security Activated', 
                    result.message
                );
            }

            // Auto-fill profile email from reg email
            setProfile(prev => ({ ...prev, email: regEmail }));
        }

        setError('');
        setStep(s => s + 1);
    };


    const prevStep = () => {
        setError('');
        if (showRestoreFields) {
            setShowRestoreFields(false);
        } else {
            setStep(s => s - 1);
        }
    };

    const executeRestore = () => {
        setIsProcessing(true); // Immediate feedback
        setError('');

        console.log("🏦 Restore Process Initiated...");

        const file = backupFileRef.current?.files?.[0];
        if (!file) {
            console.warn("⚠️ No backup file selected.");
            setError('Please select a backup file first.');
            setIsProcessing(false);
            return;
        }

        if (!encryptionKey) {
            console.warn("⚠️ No decryption password provided.");
            setError('Decryption password is required to unlock this backup.');
            setIsProcessing(false);
            return;
        }

        if (!adminPassword) {
            console.warn("⚠️ Admin credentials lost.");
            setError('Admin credentials from the previous step were not found. Please go back and re-enter your administrator details.');
            setIsProcessing(false);
            return;
        }

        const reader = new FileReader();

        reader.onerror = (err) => {
            console.error("❌ FileReader Error:", err);
            setIsProcessing(false);
            setError('Failed to read the backup file. It might be in use by another program.');
        };

        reader.onload = async (e) => {
            console.log("📄 Backup file loaded into memory. Length:", (e.target?.result as string).length);
            try {
                const encryptedContent = e.target?.result as string;
                if (!encryptedContent) throw new Error("File is empty or corrupt");

                let decryptedString = '';
                try {
                    const bytes = CryptoJS.AES.decrypt(encryptedContent, encryptionKey);
                    decryptedString = bytes.toString(CryptoJS.enc.Utf8);

                    if (!decryptedString || decryptedString.length < 10) {
                        throw new Error("Invalid Decryption Result");
                    }
                } catch (cryptoErr) {
                    console.error("Decryption Error:", cryptoErr);
                    throw new Error("Incorrect Password: Could not decrypt the file.");
                }

                let data;
                try {
                    data = JSON.parse(decryptedString);
                } catch (parseErr) {
                    throw new Error("Invalid Format: Decrypted data is not a valid backup.");
                }

                // Create Admin User from state (collected in Step 2)
                const adminUser: User = {
                    username: userID || 'admin',
                    password: adminPassword,
                    name: userName || 'System Administrator',
                    role: 'Administrator',
                    email: data.companyProfile?.email || data.app_company_profile?.email || 'admin@bharatpay.com'
                };

                // Sync Password to Cloud (Background)
                updateCloudPassword(adminUser.email, adminUser.password || '', regOTP).catch(e => console.error("Cloud Password Sync Failed:", e));

                // Backup EVERYTHING critical before clearing (Strict Preservation)
                const currentLicense = localStorage.getItem('app_license_secure');
                const lastCheck = localStorage.getItem('app_license_last_check');
                const mid = localStorage.getItem('app_machine_id');
                const size = localStorage.getItem('app_data_size');

                // Surgical Clear: Remove only data keys, PROTECT system and identity keys
                Object.keys(localStorage).forEach(key => {
                    const isScoped = activeCompanyId && key.startsWith(`${activeCompanyId}_app_`);
                    const isLegacy = key.startsWith('app_');

                    if (isScoped || isLegacy) {
                        const isSystemKey = key.includes('license') ||
                            key === 'app_machine_id' ||
                            key === 'app_setup_complete' ||
                            key === 'app_companies' ||
                            key === 'app_active_company_id' ||
                            key === 'app_data_size';
                        if (!isSystemKey) {
                            localStorage.removeItem(key);
                        }
                    }
                });

                // HELPER: Get value from unified or legacy key
                const getVal = (key: string) => data[key] || data[`app_${key}`];

                // HELPER: Get company-aware key
                const getCKey = (key: string) => {
                    if (!activeCompanyId || activeCompanyId === 'default') return key;
                    return `${activeCompanyId}_${key}`;
                };

                // Restore Core Keys (Unified & Legacy Fallback)
                const employees = getVal('employees');
                const config = getVal('config');
                const profile = getVal('companyProfile');
                const attendance = getVal('attendance');
                const leaveLedgers = getVal('leaveLedgers');
                const advanceLedgers = getVal('advanceLedgers');
                const payrollHistory = getVal('payrollHistory');
                const fines = getVal('fines');
                const leavePolicy = getVal('leavePolicy');
                const arrearHistory = getVal('arrearHistory');
                const logo = getVal('logo');

                if (employees) localStorage.setItem(getCKey('app_employees'), JSON.stringify(employees));
                if (config) localStorage.setItem(getCKey('app_config'), JSON.stringify(config));
                if (profile) {
                    localStorage.setItem(getCKey('app_company_profile'), JSON.stringify(profile));
                    // Also update the app_companies list if this profile is different
                    const savedCos = localStorage.getItem('app_companies');
                    if (savedCos) {
                        try {
                            const cos = JSON.parse(savedCos);
                            const idx = cos.findIndex((c: any) => c.id === activeCompanyId);
                            if (idx !== -1) {
                                cos[idx] = { ...profile, id: activeCompanyId };
                                localStorage.setItem('app_companies', JSON.stringify(cos));
                            }
                        } catch (e) {}
                    }
                }
                if (attendance) localStorage.setItem(getCKey('app_attendance'), JSON.stringify(attendance));
                if (leaveLedgers) localStorage.setItem(getCKey('app_leave_ledgers'), JSON.stringify(leaveLedgers));
                if (advanceLedgers) localStorage.setItem(getCKey('app_advance_ledgers'), JSON.stringify(advanceLedgers));
                if (payrollHistory) localStorage.setItem(getCKey('app_payroll_history'), JSON.stringify(payrollHistory));
                if (fines) localStorage.setItem(getCKey('app_fines'), JSON.stringify(fines));
                if (leavePolicy) localStorage.setItem(getCKey('app_leave_policy'), JSON.stringify(leavePolicy));
                if (arrearHistory) localStorage.setItem(getCKey('app_arrear_history'), JSON.stringify(arrearHistory));
                if (logo) localStorage.setItem(getCKey('app_logo'), JSON.stringify(logo));

                const masters = data.masters || data.app_masters;
                if (masters) {
                    localStorage.setItem(getCKey('app_master_designations'), JSON.stringify(masters.designations));
                    localStorage.setItem(getCKey('app_master_divisions'), JSON.stringify(masters.divisions));
                    localStorage.setItem(getCKey('app_master_branches'), JSON.stringify(masters.branches));
                    localStorage.setItem(getCKey('app_master_sites'), JSON.stringify(masters.sites));
                }

                // Ensure License and Machine identity are still correct (re-apply to be safe)
                if (currentLicense) localStorage.setItem('app_license_secure', currentLicense);
                if (lastCheck) localStorage.setItem('app_license_last_check', lastCheck);
                if (mid) localStorage.setItem('app_machine_id', mid);
                if (size) localStorage.setItem('app_data_size', size);

                // Apply newly set Admin password to the restored system
                localStorage.setItem('app_users', JSON.stringify([adminUser]));
                localStorage.setItem('app_setup_complete', 'true');
                sessionStorage.setItem('app_session_user', JSON.stringify(adminUser));

                await delay(800);
                setIsProcessing(false);
                if (showAlert) {
                    showAlert('success', 'Restoration Complete', '✅ Your data has been restored successfully! The application will now reload to apply changes.', () => {
                        onRestore();
                    });
                } else {
                    onRestore(); // Refresh app
                }
            } catch (err: any) {
                console.error("Restore Execution Failed:", err);
                setIsProcessing(false);
                setError(err.message || "An unexpected error occurred during restoration.");
                containerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
            }
        };
        reader.readAsText(file);
    };


    const handleFreshSetup = async () => {
        setIsProcessing(true);

        // Sync Password to Cloud (Wait for result to ensure integrity)
        try {
            await updateCloudPassword(regEmail || 'admin@bharatpay.com', adminPassword, regOTP);
        } catch (e) {
            console.warn("Initial Cloud Password Sync Failed (Setup Mode):", e);
        }

        // Pre-fill empty data to bypass steps 4 and 5
        onComplete({
            companyProfile: { ...INITIAL_COMPANY_PROFILE, establishmentName: companyName, dashboardPassword: companyPass },
            statutoryConfig: INITIAL_STATUTORY_CONFIG,

            adminUser: {
                username: userID || 'admin',
                password: adminPassword,
                name: userName || 'System Administrator',
                role: 'Administrator',
                email: regEmail || 'admin@bharatpay.com'
            }
        });
    };

    const renderStepIndicator = () => (
        <div className="flex items-center justify-center gap-4 mb-4">
            {[1, 2, 3, 4].map((s) => (
                <React.Fragment key={s}>
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all duration-300 ${step === s
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30 scale-110 ring-4 ring-blue-900/10'
                        : step > s
                            ? 'bg-emerald-500 text-white'
                            : 'bg-slate-800 text-slate-500 border border-slate-700'
                        }`}>
                        {step > s ? <CheckCircle2 size={20} /> : s}
                    </div>
                    {s < 4 && <div className={`w-12 h-0.5 rounded ${step > s ? 'bg-emerald-500' : 'bg-slate-800'}`} />}
                </React.Fragment>
            ))}
        </div>
    );

    return (
        <div className="min-h-screen w-full bg-[#020617] flex items-center justify-center p-2 md:p-4 relative overflow-hidden">
            <style>
                {`
                    .no-scrollbar::-webkit-scrollbar { display: none; }
                    .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
                `}
            </style>
            {/* Background Decor */}
            <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
                <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[100px]"></div>
                <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-emerald-900/10 rounded-full blur-[100px]"></div>
            </div>

            {/* Registration Card */}
            <div className="w-full max-w-6xl relative z-10 bg-[#1e293b] border border-slate-700 rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row md:h-[min(800px,90vh)]">
                {/* Quit Application Button */}
                <button
                    onClick={() => (window as any).electronAPI?.closeApp()}
                    className="absolute top-6 right-6 z-20 p-2.5 bg-slate-800/50 hover:bg-red-600/10 text-red-500 hover:text-red-400 rounded-xl border border-slate-700 hover:border-red-500/50 transition-all flex items-center gap-2 group"
                    title="Quit Application"
                >
                    <Power size={18} className="group-hover:scale-110 transition-transform" />
                    <span className="text-[10px] font-black uppercase tracking-widest px-1 hidden md:block">Quit Application</span>
                </button>

                {/* Left: Branding & Info (50/50) */}
                <div className="md:w-1/2 bg-[#0f172a] p-8 md:p-10 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-slate-800 text-center relative overflow-hidden group shrink-0">
                    <div className="absolute inset-0 bg-blue-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-1000"></div>

                    <div className="relative z-10 flex flex-col items-center gap-8">
                        {/* Logo Section */}
                        <div className="relative">
                            <div className="absolute -inset-4 bg-gradient-to-tr from-blue-600 to-emerald-600 rounded-full blur-xl opacity-20 group-hover:opacity-40 transition-opacity duration-700"></div>
                            <div className="relative flex items-center justify-center w-32 h-32 rounded-full bg-transparent shadow-2xl overflow-hidden border-4 border-white transform group-hover:scale-105 transition-transform duration-500">
                                <img
                                    src={BRAND_CONFIG.logoUrl}
                                    alt={BRAND_CONFIG.companyName}
                                    className="w-full h-full object-cover"
                                />
                            </div>
                        </div>

                        {/* App Title Section */}
                        <div className="space-y-3">
                            <div className="flex flex-col items-center gap-1">
                                <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full mb-2">
                                    <IndianRupee size={14} className="text-[#FF9933]" />
                                    <span className="text-[9px] font-black text-blue-400 uppercase tracking-[0.2em]">Enterprise Payroll Solutions</span>
                                </div>
                                <h1 className="text-4xl font-black tracking-tighter leading-none">
                                    <span className="text-[#FF9933] drop-shadow-sm">Bharat</span>
                                    <span className="text-white drop-shadow-md">Pay</span>
                                    <span className="text-[#4ADE80]">{BRAND_CONFIG.appNameSuffix}</span>
                                </h1>
                            </div>
                            <div className="h-1 w-24 bg-gradient-to-r from-transparent via-blue-500 to-transparent mx-auto rounded-full opacity-50"></div>
                        </div>

                        {/* Developer Section */}
                        <div className="pt-4 flex flex-col items-center gap-2">
                            <span className="text-[10px] text-slate-500 font-bold tracking-widest uppercase opacity-60">Architected & Engineered by</span>
                            <div className="flex items-center gap-3 px-5 py-2.5 bg-slate-900/50 border border-slate-800 rounded-2xl">
                                <span className="text-sm font-black text-[#FF9933] tracking-wide">{BRAND_CONFIG.companyName}</span>
                            </div>
                            <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em] mt-1">Decoding Indian Labour Laws</p>
                        </div>
                    </div>
                </div>

                {/* Right: Registration Content */}
                <div ref={containerRef} className="flex-1 p-6 md:p-8 flex flex-col overflow-y-auto no-scrollbar">
                    <div className="mb-4 text-center flex flex-col items-center">
                        <h2 className="text-xl font-black text-white mb-1 uppercase tracking-tight">System Initialization</h2>
                        <p className="text-xs text-slate-400 max-w-sm">Complete the following steps to personalize your BharatPay Pro environment.</p>
                        {isNewCompany && (
                            <button 
                                onClick={() => window.location.reload()} 
                                className="mt-2 text-[10px] font-black text-rose-500 uppercase tracking-widest hover:text-rose-400 transition-colors"
                            >
                                Cancel & Return to Dashboard
                            </button>
                        )}
                    </div>

                    {renderStepIndicator()}

                    {error && (
                        <div className="mb-6 p-5 bg-red-900/20 border border-red-500/40 rounded-2xl flex flex-col gap-4 animate-in shake duration-300 shadow-xl shadow-red-950/20">
                            <div className="flex items-start gap-4">
                                <div className="p-2 bg-red-500/20 rounded-lg">
                                    <ShieldAlert size={20} className="text-red-400" />
                                </div>
                                <div className="space-y-1">
                                    <h4 className="text-[10px] font-black text-red-400 uppercase tracking-[0.2em]">Security Alert / Validation Error</h4>
                                    <p className="text-xs text-red-200 leading-relaxed font-medium">{error}</p>
                                </div>
                            </div>
                            
                            {(error.includes('Unauthorised') || error.includes('Security') || error.includes('Integrity')) && (
                                <div className="pt-2 border-t border-red-500/20 flex flex-col gap-3">
                                    <p className="text-[10px] text-red-300/70 font-bold uppercase tracking-wider text-center">
                                        Possible system corruption or version mismatch detected.
                                    </p>
                                    <button 
                                        onClick={() => onSystemRepair?.()}
                                        className="w-full py-3 bg-red-600 hover:bg-red-500 text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-xl transition-all shadow-lg shadow-red-900/30 flex items-center justify-center gap-2 group"
                                    >
                                        <RotateCw size={14} className="group-hover:rotate-180 transition-transform duration-700" />
                                        Self-Repair & Install Latest Version
                                    </button>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Step 1: Identity Verification */}
                    {step === 1 && (
                        <div className="space-y-4 animate-in slide-in-from-right-4 duration-300">
                            <div className="bg-blue-900/10 border border-blue-500/20 p-6 rounded-2xl">
                                <div className="flex items-center gap-3 mb-4">
                                    <ShieldCheck className="text-blue-400" size={28} />
                                    <h3 className="font-bold text-xl text-white">Identity Verification</h3>
                                </div>
                                <p className="text-sm text-slate-400 mb-6 leading-relaxed">
                                    Enter your registered email and mobile number. A verification code will be sent to your email to confirm your identity before proceeding to password setup.
                                </p>

                                <div className="space-y-4">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="md:col-span-2 space-y-2">
                                            <div className="flex items-center justify-between pl-1">
                                                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Registered Email ID *</label>
                                                {emailVerifyState === 'verified' && (
                                                    <span className="flex items-center gap-1 text-[10px] font-black text-emerald-400 uppercase tracking-wide">
                                                        <BadgeCheck size={13} /> Verified
                                                    </span>
                                                )}
                                            </div>
                                            <div className="relative">
                                                <Mail className={`absolute left-3 top-1/2 -translate-y-1/2 ${emailVerifyState === 'verified' ? 'text-emerald-500' : 'text-slate-500'}`} size={18} />
                                                <input
                                                    type="email"
                                                    title="Registered Email"
                                                    aria-label="Registered Email"
                                                    disabled={emailVerifyState === 'verified' || emailVerifyState === 'verifying'}
                                                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 pl-10 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all placeholder:text-slate-600 disabled:opacity-50"
                                                    placeholder="Enter your registered email address"
                                                    value={regEmail}
                                                    onChange={e => setRegEmail(e.target.value.toLowerCase())}
                                                />
                                            </div>
                                        </div>

                                        <div className="space-y-2">
                                            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Registered Mobile Number *</label>
                                            <div className="relative">
                                                <Phone className={`absolute left-3 top-1/2 -translate-y-1/2 ${emailVerifyState === 'verified' ? 'text-emerald-500' : 'text-slate-500'}`} size={18} />
                                                <input
                                                    type="tel"
                                                    title="Mobile Number"
                                                    aria-label="Mobile Number"
                                                    disabled={emailVerifyState === 'verified' || emailVerifyState === 'verifying'}
                                                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 pl-10 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all placeholder:text-slate-600 disabled:opacity-50 uppercase"
                                                    placeholder="9876543210"
                                                    value={regMobile}
                                                    onChange={e => setRegMobile(e.target.value.replace(/\D/g, '').slice(0, 10))}
                                                />
                                            </div>
                                        </div>

                                        <div className="flex items-end">
                                            {emailVerifyState === 'idle' ? (
                                                <button
                                                    type="button"
                                                    onClick={handleSendEmailOTP}
                                                    disabled={!regEmail.includes('@') || regMobile.length < 10}
                                                    className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-black uppercase text-xs rounded-xl transition-all shadow-lg shadow-blue-900/20"
                                                >
                                                    Send Verification OTP
                                                </button>
                                            ) : emailVerifyState === 'verified' ? (
                                                <div className="w-full py-3.5 bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 font-black uppercase text-xs rounded-xl flex items-center justify-center gap-2">
                                                    <BadgeCheck size={16} /> Identity Confirmed
                                                </div>
                                            ) : null}
                                        </div>
                                    </div>

                                    {(emailVerifyState === 'otp_pending' || emailVerifyState === 'verifying') && (
                                        <div className="p-5 bg-blue-950/20 border border-blue-500/30 rounded-2xl space-y-4 animate-in fade-in zoom-in duration-300">
                                            <div className="flex items-center justify-between px-1">
                                                <label className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Enter 6-Digit OTP</label>
                                                <button onClick={() => setEmailVerifyState('idle')} className="text-[10px] text-slate-500 hover:text-white uppercase font-black transition-colors">Change Contact</button>
                                            </div>
                                            <div className="flex gap-3">
                                                <input
                                                    ref={otpInputRef}
                                                    type="text"
                                                    inputMode="numeric"
                                                    maxLength={6}
                                                    className="flex-1 bg-slate-950 border border-blue-500/40 rounded-xl p-3 text-white text-center font-mono text-lg tracking-[0.4em] focus:ring-2 focus:ring-blue-500/50 outline-none transition-all"
                                                    placeholder="______"
                                                    value={regOTP}
                                                    onChange={e => setRegOTP(e.target.value.replace(/\D/g, '').slice(0, 6))}
                                                />
                                                <button
                                                    onClick={handleVerifyEmailOTP}
                                                    disabled={regOTP.length !== 6 || emailVerifyState === 'verifying'}
                                                    className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase text-xs rounded-xl shadow-lg shadow-emerald-900/20 disabled:opacity-50 transition-all flex items-center justify-center min-w-[120px]"
                                                >
                                                    {emailVerifyState === 'verifying' ? <Loader2 size={16} className="animate-spin" /> : 'Confirm OTP'}
                                                </button>
                                            </div>
                                            {emailVerifyMsg && <p className="text-[10px] text-amber-500 font-bold uppercase text-center tracking-wide">{emailVerifyMsg}</p>}
                                        </div>
                                    )}

                                    {emailVerifyState === 'verified' && (
                                        <div className="flex justify-end pt-4">
                                            <button
                                                onClick={nextStep}
                                                className="group px-12 py-4 bg-blue-600 hover:bg-blue-500 text-white font-black uppercase tracking-widest rounded-xl transition-all shadow-xl shadow-blue-900/20 flex items-center gap-3"
                                            >
                                                Set Credentials <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Step 2: Set User ID and Password */}
                    {step === 2 && (
                        <div className="space-y-4 animate-in slide-in-from-right-4 duration-300">
                            <div className="bg-blue-900/10 border border-blue-500/20 p-6 rounded-2xl">
                                <div className="flex items-center gap-3 mb-4">
                                    <div className="p-2.5 bg-blue-500/10 rounded-xl">
                                        <Lock className="text-blue-400" size={24} />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-xl text-white uppercase tracking-tight">Security Setup</h3>
                                        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Define your administrator profile and secure system password</p>
                                    </div>
                                </div>

                                <div className="space-y-6">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="md:col-span-2 space-y-2">
                                            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Full Name / Authorized Person</label>
                                            <div className="relative">
                                                <UserCircle className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-400" size={18} />
                                                <input
                                                    type="text"
                                                    readOnly={isFetchedIdentity}
                                                    className={`w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 pl-10 text-white outline-none uppercase font-black tracking-wide ${isFetchedIdentity ? 'cursor-not-allowed opacity-80' : 'focus:ring-2 focus:ring-blue-500/50'}`}
                                                    value={userName}
                                                    onChange={e => !isFetchedIdentity && setUserName(e.target.value.toUpperCase())}
                                                    placeholder="Your Name"
                                                />
                                            </div>
                                        </div>
                                        <div className="space-y-2">
                                            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">User ID</label>
                                            <div className="relative">
                                                <UserPlus className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-400" size={18} />
                                                <input
                                                    type="text"
                                                    readOnly={isFetchedIdentity}
                                                    className={`w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 pl-10 text-white outline-none font-black tracking-widest ${isFetchedIdentity ? 'cursor-not-allowed opacity-80' : 'focus:ring-2 focus:ring-blue-500/50'}`}
                                                    value={userID}
                                                    onChange={e => !isFetchedIdentity && setUserID(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12))}
                                                    placeholder="Login ID"
                                                />
                                            </div>
                                        </div>
                                        {(!isTrialUser || showKeyInput) && (
                                            <div className="space-y-2 animate-in slide-in-from-top-2 duration-300">
                                                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">License Key (16-Digit)</label>
                                                <input
                                                    type="text"
                                                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-white font-mono text-center tracking-[0.2em] focus:ring-2 focus:ring-blue-500/50 outline-none transition-all placeholder:text-slate-700"
                                                    placeholder="XXXX-XXXX-XXXX-XXXX"
                                                    value={licenseKey}
                                                    onChange={e => {
                                                        const val = e.target.value.toUpperCase().replace(/[^0-9A-Z]/g, '').slice(0, 16);
                                                        const formatted = val.match(/.{1,4}/g)?.join('-') || val;
                                                        setLicenseKey(formatted);
                                                    }}
                                                />
                                            </div>
                                        )}
                                        {isTrialUser && !showKeyInput && (
                                            <div className="p-4 bg-blue-500/5 border border-blue-500/10 rounded-xl flex flex-col items-center gap-3">
                                                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Upgrade to Full System</p>
                                                <button 
                                                    onClick={() => setShowKeyInput(true)}
                                                    className="px-4 py-2 bg-blue-600/20 hover:bg-blue-600 text-blue-400 hover:text-white text-[9px] font-black uppercase tracking-[0.2em] rounded-lg border border-blue-500/30 transition-all flex items-center gap-2"
                                                >
                                                    <KeyRound size={12} />
                                                    Activate License Key
                                                </button>
                                            </div>
                                        )}
                                    </div>

                                    {/* Password Setup */}
                                    <div className="p-6 bg-slate-950/50 border border-slate-800 rounded-2xl space-y-4">
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Administrator Password *</label>
                                                <div className="relative">
                                                    <input
                                                        type="password"
                                                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all font-mono"
                                                        placeholder="••••••••"
                                                        value={adminPassword}
                                                        onChange={e => setAdminPassword(e.target.value)}
                                                    />
                                                </div>
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Confirm Password *</label>
                                                <div className="relative">
                                                    <input
                                                        type="password"
                                                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all font-mono"
                                                        placeholder="••••••••"
                                                        value={confirmPassword}
                                                        onChange={e => setConfirmPassword(e.target.value)}
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 mt-2 px-1">
                                            <div className="flex items-center gap-2 text-[9px] font-bold">
                                                <div className={`w-1.5 h-1.5 rounded-full ${adminPassword.length >= 9 ? 'bg-emerald-500 shadow-[0_0_5px_#10b981]' : 'bg-slate-700'}`} />
                                                <span className={adminPassword.length >= 9 ? 'text-emerald-400' : 'text-slate-500'}>9+ Characters</span>
                                            </div>
                                            <div className="flex items-center gap-2 text-[9px] font-bold">
                                                <div className={`w-1.5 h-1.5 rounded-full ${/[A-Z]/.test(adminPassword) && /[a-z]/.test(adminPassword) ? 'bg-emerald-500 shadow-[0_0_5px_#10b981]' : 'bg-slate-700'}`} />
                                                <span className={/[A-Z]/.test(adminPassword) && /[a-z]/.test(adminPassword) ? 'text-emerald-400' : 'text-slate-500'}>Mixed Case</span>
                                            </div>
                                            <div className="flex items-center gap-2 text-[9px] font-bold">
                                                <div className={`w-1.5 h-1.5 rounded-full ${/\d/.test(adminPassword) ? 'bg-emerald-500 shadow-[0_0_5px_#10b981]' : 'bg-slate-700'}`} />
                                                <span className={/\d/.test(adminPassword) ? 'text-emerald-400' : 'text-slate-500'}>Numbers</span>
                                            </div>
                                            <div className="flex items-center gap-2 text-[9px] font-bold">
                                                <div className={`w-1.5 h-1.5 rounded-full ${/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(adminPassword) ? 'bg-emerald-500 shadow-[0_0_5px_#10b981]' : 'bg-slate-700'}`} />
                                                <span className={/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(adminPassword) ? 'text-emerald-400' : 'text-slate-500'}>Symbol</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex justify-between pt-4">
                                        <button onClick={prevStep} className="px-8 py-4 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl transition-all uppercase tracking-widest text-xs flex items-center gap-2">
                                            <ArrowLeft size={16} /> Back
                                        </button>
                                        <button
                                            onClick={nextStep}
                                            disabled={isProcessing}
                                            className="group px-12 py-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-black uppercase tracking-widest rounded-xl transition-all shadow-xl shadow-blue-900/20 flex items-center gap-3"
                                        >
                                            {isProcessing ? <Loader2 className="animate-spin" /> : <>Activate Security <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" /></>}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Step 3: Administrator Identity Confirmation */}
                    {step === 3 && (
                        <div className="space-y-4 animate-in slide-in-from-right-4 duration-300">
                            <div className="bg-emerald-900/5 border border-emerald-500/10 p-6 rounded-2xl">
                                <div className="flex items-center gap-4 mb-6">
                                    <div className="p-3 bg-emerald-500/10 rounded-2xl">
                                        <BadgeCheck className="text-emerald-400" size={32} />
                                    </div>
                                    <div>
                                        <h3 className="font-black text-xl text-white uppercase tracking-tight">Identity Secured</h3>
                                        <p className="text-sm text-slate-400">Your administrative profile and hardware ID have been bound together.</p>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl space-y-1">
                                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Active User ID</label>
                                        <p className="text-lg font-black text-white tracking-wide">{userID}</p>
                                    </div>
                                    <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl space-y-1">
                                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Profile Name</label>
                                        <p className="text-lg font-black text-white tracking-wide">{userName}</p>
                                    </div>
                                    <div className="md:col-span-2 p-4 bg-slate-900/50 border border-slate-800 rounded-xl space-y-1">
                                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Verified Email</label>
                                        <p className="text-sm font-black text-emerald-400 tracking-wide">{regEmail}</p>
                                    </div>
                                </div>
                                <div className="mt-6 flex items-center gap-3 p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-xl">
                                    <CheckCircle2 size={16} className="text-emerald-500" />
                                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">4-Field Match established and synced to cloud</p>
                                </div>
                            </div>

                            <div className="flex justify-end pt-4">
                                <button
                                    onClick={nextStep}
                                    className="group px-10 py-4 bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest rounded-xl shadow-2xl shadow-blue-500/20 transition-all flex items-center gap-3"
                                >
                                    Proceed to Initialization <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                                </button>
                            </div>
                        </div>
                    )}


                    {/* Step 4: Choice (Restore vs Manual) */}
                    {step === 4 && (
                        <div className="space-y-4 animate-in slide-in-from-right-4 duration-300">
                            {!showRestoreFields && !showCompanyInput ? (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {!isResetMode && (
                                        <div
                                            onClick={() => setShowRestoreFields(true)}
                                            className="bg-[#0f172a] p-6 rounded-2xl border-2 border-slate-800 hover:border-blue-500/50 transition-all cursor-pointer group flex flex-col items-center text-center"
                                        >
                                            <div className="w-12 h-12 rounded-full bg-blue-900/20 text-blue-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                                                <Database size={28} />
                                            </div>
                                            <h3 className="text-lg font-bold mb-1 text-slate-100">Restore Data Backup</h3>
                                            <p className="text-xs text-slate-400 leading-relaxed px-2">Recommended if you have a backup of employees, profiles, and attendance.</p>
                                            <div className="mt-4 px-5 py-1.5 bg-blue-600 group-hover:bg-blue-700 text-white font-bold rounded-lg transition-colors text-sm">Select Backup File</div>
                                        </div>
                                    )}

                                    <div
                                        onClick={() => setShowCompanyInput(true)}
                                        className={`bg-[#0f172a] ${isResetMode ? 'md:col-span-2' : ''} p-8 rounded-2xl border-2 border-slate-800 hover:border-emerald-500/50 transition-all cursor-pointer group flex flex-col items-center text-center`}
                                    >
                                        <div className="w-16 h-16 rounded-full bg-emerald-900/20 text-emerald-400 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                                            <Building2 size={32} />
                                        </div>
                                        <h3 className="text-xl font-bold mb-3 text-slate-100">Manual Configuration</h3>
                                        <p className="text-sm text-slate-400 leading-relaxed px-4">Start fresh by defining your establishment profile and statutory rules manually. Best for new installations.</p>
                                        <div className="mt-8 px-6 py-2 bg-emerald-600 group-hover:bg-emerald-700 text-white font-bold rounded-lg transition-colors flex items-center gap-2">Start Fresh Setup <ArrowRight size={16} /></div>
                                    </div>
                                </div>
                            ) : showCompanyInput ? (
                                <div className="bg-[#1e293b]/50 border border-slate-800 p-8 rounded-2xl space-y-8 animate-in zoom-in-95 duration-200">
                                    <div className="flex items-center gap-3">
                                        <Building2 className="text-emerald-400" size={24} />
                                        <h3 className="font-bold text-lg text-white uppercase tracking-tight">Create Establishment</h3>
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div className="space-y-3">
                                            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Establishment Name *</label>
                                            <input
                                                type="text"
                                                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-white focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all font-black uppercase tracking-wide"
                                                placeholder="ENTER COMPANY NAME"
                                                value={companyName}
                                                onChange={e => setCompanyName(e.target.value.toUpperCase())}
                                                autoFocus
                                            />
                                        </div>
                                        <div className="space-y-3">
                                            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Database Access Password (Optional)</label>
                                            <div className="relative">
                                                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                                                <input
                                                    type={showPin ? "text" : "password"}
                                                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 pl-12 pr-12 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all font-bold"
                                                    placeholder="Leave blank for no password"
                                                    value={companyPass}
                                                    onChange={e => setCompanyPass(e.target.value)}
                                                />
                                                <button 
                                                    type="button"
                                                    onClick={() => setShowPin(!showPin)}
                                                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-blue-400 transition-colors"
                                                >
                                                    {showPin ? <EyeOff size={18} /> : <Eye size={18} />}
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex justify-between pt-4">
                                        <button onClick={() => setShowCompanyInput(false)} className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl transition-all uppercase tracking-widest text-xs flex items-center gap-2">
                                            Cancel
                                        </button>
                                        <button
                                            onClick={handleFreshSetup}
                                            disabled={!companyName.trim() || isProcessing}
                                            className="px-8 py-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-black uppercase tracking-widest rounded-xl transition-all flex items-center gap-2"
                                        >
                                            {isProcessing ? <Loader2 className="animate-spin" size={18} /> : 'Initialize Unit'}
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                <div className="bg-[#1e293b]/50 border border-slate-800 p-8 rounded-2xl space-y-8 animate-in zoom-in-95 duration-200">
                                    <div className="flex items-center gap-3">
                                        <Database className="text-blue-400" size={24} />
                                        <h3 className="font-bold text-lg">Restore Data Backup</h3>
                                    </div>

                                    <div className="space-y-6">
                                        <div className="space-y-2">
                                            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Backup File (.enc)</label>
                                            <input
                                                ref={backupFileRef}
                                                type="file"
                                                accept=".enc"
                                                title="Select Backup File"
                                                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-slate-400 file:bg-blue-600 file:border-none file:text-white file:px-4 file:py-1.5 file:rounded-lg file:mr-4 file:font-bold hover:file:bg-blue-700"
                                                onChange={(e) => {
                                                    if (e.target.files && e.target.files.length > 0) {
                                                        // Auto-focus the password field after selecting a file
                                                        setTimeout(() => decryptPasswordRef.current?.focus(), 100);
                                                    }
                                                }}
                                            />
                                        </div>

                                        <div className="space-y-2">
                                            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Decryption Password</label>
                                            <div className="relative">
                                                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                                                <input
                                                    ref={decryptPasswordRef}
                                                    type="password"
                                                    value={encryptionKey}
                                                    onChange={e => setEncryptionKey(e.target.value)}
                                                    title="Decryption Password"
                                                    aria-label="Decryption Password"
                                                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 pl-10 text-white focus:ring-2 focus:ring-blue-500/50 outline-none transition-all font-mono"
                                                    placeholder="Enter decryption password"
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex justify-between">
                                        <button
                                            onClick={() => setShowRestoreFields(false)}
                                            className="px-8 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl transition-all"
                                        >
                                            Back to Choice
                                        </button>
                                        <button
                                            onClick={executeRestore}
                                            disabled={isProcessing}
                                            className="px-10 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-black uppercase tracking-widest rounded-xl shadow-xl shadow-blue-500/20 transition-all flex items-center gap-2 disabled:opacity-50"
                                        >
                                            {isProcessing ? <Loader2 className="animate-spin" size={20} /> : <Upload size={20} />} Restore & Finish
                                        </button>
                                    </div>
                                </div>
                            )}

                            {!showRestoreFields && (
                                <button
                                    onClick={prevStep}
                                    className="mt-4 text-slate-500 hover:text-slate-300 transition-colors flex items-center gap-2"
                                >
                                    <ArrowLeft size={16} /> Back to Administration Step
                                </button>
                            )}
                        </div>
                    )}

                    <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-center gap-2 text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em]">
                        Powered by <span className="text-slate-300">BharatPay Pro</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Registration;
