
import { StatutoryConfig, Employee, User, LeavePolicy, CompanyProfile } from './types';

// Branding Configuration
export const BRAND_CONFIG = {
  appName: 'BharatPay',
  appNameSuffix: ' Pro',
  companyName: 'ILCBala',
  tagline: 'Decoding Indian Labour Laws',
  logoUrl: './logo.png',
  developerLogoUrl: './logo3.png'
};

export const INITIAL_COMPANY_PROFILE: CompanyProfile = {
  id: 'default',
  establishmentName: '',
  tradeName: '',
  cin: '',
  lin: '',
  pfCode: '',
  esiCode: '',
  gstNo: '',
  pan: '',
  ptNo: '',
  tan: '',
  lwfRegNo: '',
  // Address
  doorNo: '',
  buildingName: '',
  street: '',
  locality: '',
  area: '',
  city: '',
  state: 'Tamil Nadu',
  pincode: '',
  // Contact
  mobile: '',
  telephone: '',
  email: '',
  website: '',
  natureOfBusiness: 'Manufacturing',
  flashNews: 'Welcome to BharatPay Pro! Ensure all PF ECRs are filed before the 15th. Check "Settings" to update this news.',
  flashNewsKey: 'REGULAR',
  postLoginMessage: '# Labour Code  2020 implemented (21-11-2025)\n# Higher Wages , Higher Pension implemented',
  postLoginHeader: 'Statutory Compliance Update',
  postLoginAlignment: 'LEFT',
  postLoginKey: 'REGULAR',
  flashPopupMessage: '',
  flashPopupHeader: 'FLASH ALERT',
  flashPopupPriority: 'REGULAR',
  flashPopupId: '',
  externalAppUrl: '', // Default empty
  securityPin: '',
  loginAlertEnabled: false,
  loginAlertMessage: ''
};

export const NATURE_OF_BUSINESS_OPTIONS = [
  'Manufacturing',
  'Services Industry',
  'Contract Labour',
  'Software / IT Services',
  'Construction',
  'Retail / Trading',
  'Hospitality',
  'Education',
  'Financial Services',
  'Logistics / Transport',
  'Healthcare',
  'Others'
];

export const INITIAL_STATUTORY_CONFIG: StatutoryConfig = {
  epfCeiling: 15000,
  epfEmployeeRate: 0.12,
  epfEmployerRate: 0.12,
  esiCeiling: 21000,
  esiEmployeeRate: 0.0075,
  esiEmployerRate: 0.0325,
  // PT Config
  enableProfessionalTax: true,
  ptDeductionCycle: 'HalfYearly',
  ptSlabs: [
    { min: 0, max: 21000, amount: 0 },
    { min: 21001, max: 30000, amount: 135 },
    { min: 30001, max: 45000, amount: 315 },
    { min: 45001, max: 60000, amount: 690 },
    { min: 60001, max: 75000, amount: 1025 },
    { min: 75001, max: 9999999, amount: 1250 }
  ],
  // LWF Config
  enableLWF: true,
  lwfDeductionCycle: 'Yearly',
  lwfEmployeeContribution: 10,
  lwfEmployerContribution: 20,

  // IT Config
  incomeTaxCalculationType: 'Manual',

  bonusRate: 0.0833,
  pfComplianceType: 'Statutory',

  // NEW: Higher Contribution Rules
  enableHigherContribution: false,
  higherContributionType: 'By Employee',
  higherContributionComponents: {
    basic: true,
    da: true,
    retaining: true,
    hra: false,
    conveyance: false,
    washing: false,
    attire: false,
    special1: false,
    special2: false,
    special3: false
  },

  // NEW: Leave Wages Calculation Policy (Default Basic + DA)
  leaveWagesComponents: {
    basic: true,
    da: true,
    retaining: false,
    hra: false,
    conveyance: false,
    washing: false,
    attire: false,
    special1: false,
    special2: false,
    special3: false
  },

  // NEW: Overtime Policy
  enableOT: false,
  otCalculationFactor: 1,
  otComponents: {
    basic: true,
    da: true,
    retaining: false,
    hra: false,
    conveyance: false,
    washing: false,
    attire: false,
    special1: false,
    special2: false,
    special3: false
  },

  // NEW: Statutory Calculation Basis (Global Policy)
  pfEsiCalculationBasis: 'LabourCode',
  pfOriginalWagesComponents: {
    basic: true,
    da: true,
    retaining: true,
    hra: false,
    conveyance: false,
    washing: false,
    attire: false,
    special1: false,
    special2: false,
    special3: false
  },
  esiOriginalWagesComponents: { basic: true, da: true, retaining: true, hra: false, conveyance: true, washing: true, attire: true, special1: true, special2: true, special3: true },
  bonusWagesComponents: { basic: true, da: true, retaining: false, hra: false, conveyance: false, washing: false, attire: false, special1: false, special2: false, special3: false },
  gratuityWagesComponents: { basic: true, da: true, retaining: false, hra: false, conveyance: false, washing: false, attire: false, special1: false, special2: false, special3: false },
  enableArrearSalary: false
};

export const DEFAULT_LEAVE_POLICY: LeavePolicy = {
  el: { maxPerYear: 18, maxCarryForward: 45, label: 'Earned Leave (EL)' },
  sl: { maxPerYear: 12, maxCarryForward: 0, label: 'Sick Leave (SL)' },
  cl: { maxPerYear: 12, maxCarryForward: 0, label: 'Casual Leave (CL)' }
};

export const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat",
  "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra",
  "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim",
  "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
  "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu",
  "Delhi", "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry"
];

export const PT_STATE_PRESETS = {
  'Tamil Nadu': {
    cycle: 'HalfYearly',
    slabs: [
      { min: 0, max: 21000, amount: 0 },
      { min: 21001, max: 30000, amount: 135 },
      { min: 30001, max: 45000, amount: 315 },
      { min: 45001, max: 60000, amount: 690 },
      { min: 60001, max: 75000, amount: 1025 },
      { min: 75001, max: 9999999, amount: 1250 }
    ]
  },
  'Karnataka': {
    cycle: 'Monthly',
    slabs: [
      { min: 0, max: 14999, amount: 0 },
      { min: 15000, max: 9999999, amount: 200 }
    ]
  },
  'Maharashtra': {
    cycle: 'Monthly',
    slabs: [
      { min: 0, max: 7500, amount: 0 },
      { min: 7501, max: 10000, amount: 175 },
      { min: 10001, max: 9999999, amount: 200 }
      // Note: In MH, Feb is 300, but simpler logic used here for standard
    ]
  },
  'West Bengal': {
    cycle: 'Monthly',
    slabs: [
      { min: 0, max: 10000, amount: 0 },
      { min: 10001, max: 15000, amount: 110 },
      { min: 15001, max: 25000, amount: 130 },
      { min: 25001, max: 40000, amount: 150 },
      { min: 40001, max: 9999999, amount: 200 }
    ]
  },
  'Telangana': {
    cycle: 'Monthly',
    slabs: [
      { min: 0, max: 15000, amount: 0 },
      { min: 15001, max: 20000, amount: 150 },
      { min: 20001, max: 9999999, amount: 200 }
    ]
  },
  'Andhra Pradesh': {
    cycle: 'Monthly',
    slabs: [
      { min: 0, max: 15000, amount: 0 },
      { min: 15001, max: 20000, amount: 150 },
      { min: 20001, max: 9999999, amount: 200 }
    ]
  },
  'Kerala': {
    cycle: 'HalfYearly',
    slabs: [
      { min: 0, max: 11999, amount: 0 },
      { min: 12000, max: 17999, amount: 120 },
      { min: 18000, max: 29999, amount: 180 },
      { min: 30000, max: 44999, amount: 300 },
      { min: 45000, max: 59999, amount: 450 },
      { min: 60000, max: 74999, amount: 600 },
      { min: 75000, max: 99999, amount: 750 },
      { min: 100000, max: 124999, amount: 1000 },
      { min: 125000, max: 9999999, amount: 1250 }
    ]
  },
  'Gujarat': {
    cycle: 'Monthly',
    slabs: [
      { min: 0, max: 12000, amount: 0 },
      { min: 12001, max: 9999999, amount: 200 }
    ]
  }
};

export const LWF_STATE_PRESETS = {
  'Tamil Nadu': { cycle: 'Yearly', emp: 10, emplr: 20 }, // Dec
  'Andhra Pradesh': { cycle: 'Yearly', emp: 30, emplr: 70 }, // Dec
  'Telangana': { cycle: 'Yearly', emp: 30, emplr: 70 }, // Dec
  'Karnataka': { cycle: 'Yearly', emp: 20, emplr: 40 }, // Dec
  'Maharashtra': { cycle: 'HalfYearly', emp: 12, emplr: 36 }, // Jun/Dec
  'Kerala': { cycle: 'HalfYearly', emp: 20, emplr: 20 }, // Jun/Dec
  'Gujarat': { cycle: 'HalfYearly', emp: 6, emplr: 12 }, // Jun/Dec
  'West Bengal': { cycle: 'HalfYearly', emp: 3, emplr: 15 }, // Jun/Dec
  'Delhi': { cycle: 'HalfYearly', emp: 0.75, emplr: 2.25 }, // (0.75 * 6 = 4.5, etc. approximate for monthly cycle if configured differently, but mostly half yearly)
  'Haryana': { cycle: 'Monthly', emp: 25, emplr: 50 },
};

export const MOCK_USERS: User[] = [
  {
    username: 'admin',
    password: 'password',
    name: 'Administrator',
    role: 'Administrator',
    email: 'admin@bharatpay.com'
  }
];

export const SAMPLE_EMPLOYEES: Employee[] = [];
