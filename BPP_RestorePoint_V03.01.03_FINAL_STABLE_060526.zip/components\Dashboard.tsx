import React, { useMemo, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { IndianRupee, Users, Building, TrendingUp, Calendar, Calculator, ArrowRight, ExternalLink, Sparkles, FileText, Upload } from 'lucide-react';
import { Employee, StatutoryConfig, Attendance, LeaveLedger, AdvanceLedger, View, CompanyProfile, PayrollResult } from '../types';
import { formatIndianNumber } from '../utils/formatters';

interface DashboardProps {
  employees: Employee[];
  config: StatutoryConfig;
  companyProfile: CompanyProfile;
  attendances: Attendance[];
  leaveLedgers: LeaveLedger[];
  advanceLedgers: AdvanceLedger[];
  payrollHistory: PayrollResult[];
  month: string;
  year: number;
  setMonth: (m: string) => void;
  setYear: (y: number) => void;
  onNavigate: (view: View, tab?: string) => void;
}

const MONTHS_LIST = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

// Find the most recently processed payroll month from history
const getLastProcessedPeriod = (history: PayrollResult[]) => {
  if (history.length === 0) return null;
  const sorted = history.slice().sort((a, b) =>
    (b.year * 12 + MONTHS_LIST.indexOf(b.month)) - (a.year * 12 + MONTHS_LIST.indexOf(a.month))
  );
  return { month: sorted[0].month, year: sorted[0].year };
};

const Dashboard: React.FC<DashboardProps> = ({ employees, companyProfile, attendances, payrollHistory, month, year, onNavigate }) => {

  const currentYear = new Date().getFullYear();
  const yearOptions = Array.from({ length: 7 }, (_, i) => currentYear - 5 + i);
  const months = MONTHS_LIST;

  // Local picker state — always defaults to last processed month, not the global period
  const lastProcessed = useMemo(() => getLastProcessedPeriod(payrollHistory), [payrollHistory]);
  const [localMonth, setLocalMonth] = useState<string>(() => lastProcessed?.month || month);
  const [localYear, setLocalYear] = useState<number>(() => lastProcessed?.year || year);

  const QuickLinks = ({ centered = false }: { centered?: boolean }) => (
    <div className={`grid grid-cols-1 ${centered ? 'md:grid-cols-2 max-w-3xl' : 'md:grid-cols-2 lg:grid-cols-4'} gap-4 w-full`}>
      <button
        onClick={() => onNavigate(View.PFCalculator)}
        title="Open PF ECR Calculator"
        aria-label="Open PF ECR Calculator"
        className="col-span-1 bg-gradient-to-r from-blue-900/30 to-[#1e293b] p-4 rounded-xl border border-blue-800/30 flex items-center justify-between group hover:border-blue-500/50 transition-all shadow-lg cursor-pointer text-left"
      >
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-600 rounded-xl text-white shadow-lg shadow-blue-900/50 group-hover:scale-110 transition-transform">
            <Calculator size={20} />
          </div>
          <div>
            <h3 className="font-bold text-white text-xs">PF ECR Calculator</h3>
            <p className="text-[9px] text-blue-200/70">Generate Challan & Returns</p>
          </div>
        </div>
        <div className="p-1.5 bg-slate-800 rounded-full text-slate-400 group-hover:bg-blue-600 group-hover:text-white transition-colors">
          <ArrowRight size={16} />
        </div>
      </button>

      <a
        href={companyProfile.externalAppUrl || '#'}
        target="_blank"
        rel="noopener noreferrer"
        title="Launch AI Studio App (External)"
        aria-label="Launch AI Studio App (External)"
        className="col-span-1 bg-gradient-to-r from-purple-900/30 to-[#1e293b] p-4 rounded-xl border border-purple-800/30 flex items-center justify-between group hover:border-purple-500/50 transition-all shadow-lg cursor-pointer text-left"
      >
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-purple-600 rounded-xl text-white shadow-lg shadow-purple-900/50 group-hover:scale-110 transition-transform">
            <Sparkles size={20} />
          </div>
          <div>
            <h3 className="font-bold text-white text-xs">Launch AI Studio App</h3>
            <p className="text-[9px] text-purple-200/70">External Comprehensive Calc</p>
          </div>
        </div>
        <div className="p-1.5 bg-slate-800 rounded-full text-slate-400 group-hover:bg-purple-600 group-hover:text-white transition-colors">
          <ExternalLink size={16} />
        </div>
      </a>

      <button
        onClick={() => onNavigate(View.MIS)}
        title="Open Management Info (MIS)"
        aria-label="Open Management Info (MIS)"
        className="col-span-1 bg-gradient-to-r from-emerald-900/30 to-[#1e293b] p-4 rounded-xl border border-emerald-800/30 flex items-center justify-between group hover:border-emerald-500/50 transition-all shadow-lg cursor-pointer text-left"
      >
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-600 rounded-xl text-white shadow-lg shadow-emerald-900/50 group-hover:scale-110 transition-transform">
            <IndianRupee size={20} />
          </div>
          <div>
            <h3 className="font-bold text-white text-xs">Management Info (MIS)</h3>
            <p className="text-[9px] text-emerald-200/70">Advanced Reporting & Mailing</p>
          </div>
        </div>
        <div className="p-1.5 bg-slate-800 rounded-full text-slate-400 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
          <ArrowRight size={16} />
        </div>
      </button>

      <button
        onClick={async () => {
          if (window.electronAPI && window.electronAPI.openUserManual) {
            const res = await window.electronAPI.openUserManual();
            if (res && !res.success) {
               alert("Unable to open user manual: " + res.error);
            }
          } else {
            alert("Application Backend Update Required: Please close and restart the BharatPay Pro application to enable the new Manual link.");
          }
        }}
        title="Open User Manual & Guidelines"
        aria-label="Open User Manual & Guidelines"
        className="col-span-1 p-4 rounded-xl border flex items-center justify-between group transition-all shadow-lg cursor-pointer text-left animate-dual-color-blink"
      >
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-orange-600 rounded-xl text-white shadow-lg shadow-orange-900/50 group-hover:scale-110 transition-transform">
            <FileText size={20} />
          </div>
          <div>
            <h3 className="font-bold text-white text-xs">User Manual & Help</h3>
            <p className="text-[9px] text-orange-200/70">Master Guidelines & Features</p>
          </div>
        </div>
        <div className="p-1.5 bg-slate-800 rounded-full text-slate-400 group-hover:bg-orange-600 group-hover:text-white transition-colors">
          <ArrowRight size={16} />
        </div>
      </button>
    </div>
  );

  // ── Derive all overview stats from payrollHistory (last saved batch) ───────

  // Find the most recent finalized batch; fall back to any saved batch for the selected local month/year
  const sourceRecords = useMemo(() => {
    // First try the locally selected month/year
    const selected = payrollHistory.filter(r => r.month === localMonth && r.year === localYear);
    if (selected.length > 0) return selected;
    // Else fall back to most recent batch
    const sorted = payrollHistory.slice().sort((a, b) =>
      (b.year * 12 + MONTHS_LIST.indexOf(b.month)) - (a.year * 12 + MONTHS_LIST.indexOf(a.month))
    );
    return sorted.filter(r => r.month === sorted[0]?.month && r.year === sorted[0]?.year);
  }, [payrollHistory, localMonth, localYear]);

  if (employees.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-10rem)] space-y-12 animate-in fade-in duration-700 py-10 px-4">
        <div className="text-center space-y-4 max-w-2xl">
          <div className="inline-flex p-4 bg-blue-500/10 rounded-2xl border border-blue-500/20 mb-4 animate-bounce">
            <Sparkles size={40} className="text-blue-400" />
          </div>
          <h2 className="text-4xl font-black text-white tracking-tight">Organization Initialized</h2>
          <p className="text-slate-400 text-lg font-medium">
            The profile and statutory rules for <span className="text-white font-bold">{companyProfile.establishmentName}</span> are now active. 
            Choose your next step to begin payroll processing.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-4xl">
          {/* Action Card: Start Fresh */}
          <button 
            onClick={() => onNavigate(View.Employees)}
            className="group p-8 bg-[#1e293b] rounded-3xl border border-slate-800 hover:border-emerald-500/50 hover:bg-slate-800/80 transition-all text-left shadow-2xl relative overflow-hidden"
          >
            <div className="absolute -right-8 -top-8 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl group-hover:bg-emerald-500/20 transition-all" />
            <div className="p-4 bg-emerald-600 rounded-2xl text-white shadow-lg shadow-emerald-900/50 mb-6 w-fit group-hover:scale-110 transition-transform">
              <Users size={32} />
            </div>
            <h3 className="text-2xl font-black text-white mb-2 uppercase tracking-tighter">Start Afresh</h3>
            <p className="text-slate-400 text-sm leading-relaxed mb-6 font-medium">
              Manually add your employees or perform a bulk Excel import to build your workforce from scratch.
            </p>
            <div className="flex items-center gap-2 text-emerald-400 font-black text-xs uppercase tracking-widest">
              Go to Employee Master <ArrowRight size={16} />
            </div>
          </button>

          {/* Action Card: Restore Backup */}
          <button 
            onClick={() => onNavigate(View.Settings, 'DATA')}
            className="group p-8 bg-[#1e293b] rounded-3xl border border-slate-800 hover:border-blue-500/50 hover:bg-slate-800/80 transition-all text-left shadow-2xl relative overflow-hidden"
          >
            <div className="absolute -right-8 -top-8 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl group-hover:bg-blue-500/20 transition-all" />
            <div className="p-4 bg-blue-600 rounded-2xl text-white shadow-lg shadow-blue-900/50 mb-6 w-fit group-hover:scale-110 transition-transform">
              <Upload size={32} />
            </div>
            <h3 className="text-2xl font-black text-white mb-2 uppercase tracking-tighter">Restore Backup</h3>
            <p className="text-slate-400 text-sm leading-relaxed mb-6 font-medium">
              Import existing data from a previously saved (.enc) backup file to quickly resume operations.
            </p>
            <div className="flex items-center gap-2 text-blue-400 font-black text-xs uppercase tracking-widest">
              Open Data Management <ArrowRight size={16} />
            </div>
          </button>
        </div>

        <div className="w-full flex flex-col items-center gap-4 mt-8 pt-8 border-t border-slate-800/50 opacity-40 grayscale pointer-events-none">
          <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Quick Access Tools (Pending Data)</h3>
          <QuickLinks centered={true} />
        </div>
      </div>
    );
  }

  const sourceLabel = sourceRecords.length > 0
    ? `${sourceRecords[0].month} ${sourceRecords[0].year}`
    : null;

  const totalGross = sourceRecords.reduce((acc, r) => acc + (r.earnings?.total || 0), 0);
  const totalEPF = sourceRecords.reduce((acc, r) =>
    acc + (r.deductions?.epf || 0) + (r.employerContributions?.epf || 0) + (r.employerContributions?.eps || 0), 0);
  const activeCount = sourceRecords.filter(r => (r.earnings?.total || 0) > 0).length;
  const totalLOP = sourceRecords.reduce((acc, r) => {
    const att = attendances.find(a => a.employeeId === r.employeeId && a.month === r.month && a.year === r.year);
    return acc + (att?.lopDays || 0);
  }, 0);

  const stats = [
    { label: 'Total Payroll Cost', value: totalGross > 0 ? `₹ ${(totalGross / 100000).toFixed(2)} L` : '—', icon: IndianRupee, color: 'text-blue-400', bg: 'bg-blue-900/30' },
    { label: 'Active Employees', value: activeCount || employees.length, icon: Users, color: 'text-emerald-400', bg: 'bg-emerald-900/30' },
    { label: 'EPF Pool', value: totalEPF > 0 ? `₹ ${formatIndianNumber(totalEPF)}` : '—', icon: Building, color: 'text-amber-400', bg: 'bg-amber-900/30' },
    { label: 'Total LOP Days', value: totalLOP, icon: TrendingUp, color: 'text-red-400', bg: 'bg-red-900/30' },
  ];

  const chartData = sourceRecords.map(res => ({
    name: employees.find(e => e.id === res.employeeId)?.name.split(' ')[0] || 'Emp',
    Net: res.netPay || 0,
    Deductions: res.deductions?.total || 0,
  }));

  const pieData = [
    // EPF = total A/c 1 (EE share + ER diff share) — matches ECR Calculator
    { name: 'EPF (EE+ER)', value: sourceRecords.reduce((a, c) => a + (c.deductions?.epf || 0) + (c.deductions?.vpf || 0) + (c.employerContributions?.epf || 0), 0) },
    // EPS = ER pension contribution — A/c 10
    { name: 'EPS (ER)', value: sourceRecords.reduce((a, c) => a + (c.employerContributions?.eps || 0), 0) },
    { name: 'ESI', value: sourceRecords.reduce((a, c) => a + (c.deductions?.esi || 0), 0) },
    { name: 'Bonus & Gratuity', value: sourceRecords.reduce((a, c) => a + (c.earnings?.bonus || 0) + (c.gratuityAccrual || 0), 0) },
    { name: 'PT / Tax', value: sourceRecords.reduce((a, c) => a + (c.deductions?.pt || 0) + (c.deductions?.it || 0), 0) },
  ];

  const COLORS = ['#3b82f6', '#818cf8', '#10b981', '#f59e0b', '#ef4444'];

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-top-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          Overview <span className="text-slate-500 text-sm font-normal">for {sourceLabel || `${localMonth} ${localYear}`}</span>
        </h2>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 bg-[#1e293b] p-1 rounded-lg border border-slate-700">
            <select
              title="Select Month"
              aria-label="Select Month"
              value={localMonth}
              onChange={e => setLocalMonth(e.target.value)}
              className="bg-[#0f172a] border border-slate-700 rounded-md px-3 py-1.5 text-xs text-white focus:ring-1 focus:ring-blue-500 outline-none font-bold"
            >
              {months.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
            <select
              title="Select Year"
              aria-label="Select Year"
              value={localYear}
              onChange={e => setLocalYear(+e.target.value)}
              className="bg-[#0f172a] border border-slate-700 rounded-md px-3 py-1.5 text-xs text-white focus:ring-1 focus:ring-blue-500 outline-none font-bold"
            >
              {yearOptions.map(y => <option key={y} value={y}>{y}</option>)}
            </select>
            <div className="px-2 text-slate-500">
              <Calendar size={14} />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((stat, i) => (
          <div key={i} className="bg-[#1e293b] p-4 rounded-xl border border-slate-800 shadow-lg hover:bg-slate-800/80 transition-all">
            <div className="flex items-center gap-3">
              <div className={`${stat.bg} ${stat.color} p-2.5 rounded-lg border border-white/5 shrink-0`}>
                <stat.icon size={20} />
              </div>
              <div>
                <p className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">{stat.label}</p>
                {stat.label === 'Active Employees' ? (
                  <div className="flex items-baseline gap-1.5 mt-0.5">
                    <h3 className="text-lg font-black text-white">{employees.length}</h3>
                    <span className="text-slate-500 font-bold text-sm">/</span>
                    <h3 className="text-lg font-black text-emerald-400">{activeCount}</h3>
                  </div>
                ) : (
                  <h3 className="text-lg font-black text-white">{stat.value}</h3>
                )}
              </div>
            </div>
            {stat.label === 'Active Employees' && (
              <div className="flex gap-3 mt-2 text-[9px] text-slate-500 font-medium pl-1">
                <span><span className="text-white font-bold">{employees.length}</span> Enrolled</span>
                <span className="text-slate-700">|</span>
                <span><span className="text-emerald-400 font-bold">{activeCount}</span> Active in {sourceLabel || 'last payroll'}</span>
              </div>
            )}
          </div>
        ))}
      </div>

      <QuickLinks />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-[#1e293b] p-5 rounded-xl border border-slate-800 shadow-lg">
          <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Net Pay vs Deductions per Employee</h3>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" />
                <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip
                  cursor={{ fill: '#334155' }}
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: '1px solid #334155', color: '#fff', fontSize: '12px' }}
                />
                <Bar dataKey="Net" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={25} />
                <Bar dataKey="Deductions" fill="#ef4444" radius={[4, 4, 0, 0]} barSize={25} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-[#1e293b] p-5 rounded-xl border border-slate-800 shadow-lg">
          <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Statutory Breakdown</h3>
          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={65}
                  paddingAngle={5}
                  dataKey="value"
                  stroke="none"
                >
                  {pieData.map((_entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '8px', color: '#ffffff', fontSize: '12px' }}
                  itemStyle={{ color: '#ffffff' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 space-y-2">
            {pieData.map((d, i) => (
              <div key={i} className="flex items-center justify-between text-[10px] px-2">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full bg-stat-${i}`}></div>
                  <span className="text-slate-400 font-medium">{d.name}</span>
                </div>
                <span className="font-bold text-white">₹ {formatIndianNumber(d.value)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
