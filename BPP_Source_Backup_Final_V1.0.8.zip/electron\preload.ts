import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('electronAPI', {
    saveReport: (fileName: string, data: Uint8Array, type: string) =>
        ipcRenderer.invoke('save-report', { fileName, data, type }),
    dbSet: (key: string, value: any) =>
        ipcRenderer.invoke('db-set', { key, value }),
    dbGet: (key: string) =>
        ipcRenderer.invoke('db-get', key),
    dbDelete: (key: string) =>
        ipcRenderer.invoke('db-delete', key),
    runBackup: (data: any) =>
        ipcRenderer.invoke('run-backup', data),
    closeApp: () => {
        console.log("Preload: Calling close-app invoke");
        return ipcRenderer.invoke('close-app');
    },
    getMachineId: () => ipcRenderer.invoke('get-machine-id'),
    selectAppDirectory: () => ipcRenderer.invoke('select-app-directory'),
    initializeAppDirectory: (path: string) => ipcRenderer.invoke('initialize-app-directory', path),
    getAppDirectory: () => ipcRenderer.invoke('get-app-directory'),
    apiFetch: (url: string, options: any) => ipcRenderer.invoke('api-fetch', url, options),
    startUpdateDownload: (url: string) => ipcRenderer.invoke('start-update-download', url),
    backupAndInstall: () => ipcRenderer.invoke('backup-and-install'),
    findBPPApp: () => ipcRenderer.invoke('find-bpp-app'),
    getIsElectron: () => true
});

console.log("EB: Electron Bridge (electronAPI) Initialized");
