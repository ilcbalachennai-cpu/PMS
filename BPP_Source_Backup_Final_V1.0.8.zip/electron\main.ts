import { app, BrowserWindow, ipcMain, dialog, net } from 'electron';
import * as path from 'path';
import * as fs from 'fs';
import Database from 'better-sqlite3';
import { https } from 'follow-redirects';
import { spawn, execSync } from 'child_process';
import * as os from 'os';

let mainWindow: BrowserWindow | null = null;
const isDev = process.env.NODE_ENV === 'development';

// ── CONFIGURATION & PERSISTENCE ──
const CONFIG_PATH = path.join(app.getPath('userData'), 'app-config.json');

function getAppConfig() {
    if (fs.existsSync(CONFIG_PATH)) {
        try {
            return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
        } catch (e) { return {}; }
    }
    return {};
}

function saveAppConfig(config: any) {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
}

let appConfig = getAppConfig();
let appBasePath = appConfig.appBasePath || '';

// Helper to get structured paths
const getAppPaths = (base: string) => {
    const root = path.join(base, 'BharatPP');
    return {
        root,
        data: path.join(root, 'Data'),
        reports: path.join(root, 'Report files'),
        backups: path.join(root, 'Data backup')
    };
};

// ── DATABASE INITIALIZATION ──
let db: any = null;

function initializeDatabase(basePath: string) {
    const paths = getAppPaths(basePath);
    // Ensure directories exist
    [paths.data, paths.reports, paths.backups].forEach((dir: string) => {
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    });

    const DB_PATH = path.join(paths.data, 'active_db.sqlite');
    const snapshotDir = path.join(paths.backups, 'PRE_UPDATE_SNAPSHOT');
    const snapshotDb = path.join(snapshotDir, 'active_db_snapshot.sqlite');

    // ── AUTO-RESTORE LOGIC ──
    // If main DB is missing but snapshot exists, restore it.
    if (!fs.existsSync(DB_PATH) && fs.existsSync(snapshotDb)) {
        try {
            console.log('🔄 Main DB missing. Restoring from pre-update snapshot...');
            fs.copyFileSync(snapshotDb, DB_PATH);
            const configSnapshot = path.join(snapshotDir, 'app-config_snapshot.json');
            if (fs.existsSync(configSnapshot)) {
                fs.copyFileSync(configSnapshot, CONFIG_PATH);
            }
            console.log('✅ Restoration complete.');
        } catch (e) {
            console.error('❌ Auto-restore failed:', e);
        }
    }

    try {
        db = new Database(DB_PATH);
        db.exec('CREATE TABLE IF NOT EXISTS store (key TEXT PRIMARY KEY, value TEXT)');
    } catch (e) {
        console.error('❌ DB connection failed. Database might be corrupted.', e);
        // If corrupted and snapshot exists, try a hail-mary restore
        if (fs.existsSync(snapshotDb)) {
            try {
                if (db) db.close();
                fs.copyFileSync(snapshotDb, DB_PATH);
                db = new Database(DB_PATH);
                console.log('🛠️ Corrupted DB replaced with snapshot.');
            } catch (restoreErr) {
                console.error('❌ Hail-mary restore failed.', restoreErr);
            }
        }
    }
}

if (appBasePath) {
    try {
        initializeDatabase(appBasePath);
    } catch (e) {
        console.error("Failed to initialize database at stored path:", e);
        appBasePath = ''; // Reset if path is invalid
    }
}

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1280,
        height: 800,
        icon: path.join(__dirname, '../build/icon.png'),
        webPreferences: {
            preload: path.isAbsolute(path.join(__dirname, 'preload.js'))
                ? path.join(__dirname, 'preload.js')
                : path.resolve(__dirname, 'preload.js'),
            nodeIntegration: false,
            contextIsolation: true,
        },
        autoHideMenuBar: true,
    });

    if (isDev) {
        mainWindow.loadURL('http://localhost:3000');
    } else {
        mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
    }

    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}

app.whenReady().then(() => {
    createWindow();
    cleanupOldInstallers();
});

app.on('window-all-closed', () => {
    console.error("EVENT 'window-all-closed' WAS FIRED. STACK TRACE:");
    console.trace();
    if (process.platform !== 'darwin') app.quit();
});

// ── IPC HANDLERS ──

// 1. Directory Setup
ipcMain.handle('select-app-directory', async () => {
    if (!mainWindow) return { success: false, error: 'No main window' };
    const result = await dialog.showOpenDialog(mainWindow, {
        properties: ['openDirectory', 'createDirectory'],
        title: 'Select Application Storage Location'
    });

    if (result.canceled || result.filePaths.length === 0) {
        return { success: false, canceled: true };
    }

    return { success: true, path: result.filePaths[0] };
});

ipcMain.handle('initialize-app-directory', async (_, selectedPath: string) => {
    try {
        initializeDatabase(selectedPath);
        appBasePath = selectedPath;
        saveAppConfig({ ...getAppConfig(), appBasePath });
        return { success: true };
    } catch (e: any) {
        console.error('Failed to initialize app directory:', e);
        return { success: false, error: e.message };
    }
});

ipcMain.handle('get-app-directory', async () => {
    return appBasePath || null;
});

// 2. Report Saving
ipcMain.handle('save-report', async (_, { fileName, data, type }) => {
    try {
        if (!appBasePath) throw new Error("App storage not initialized");
        const paths = getAppPaths(appBasePath);
        const filePath = path.join(paths.reports, `${fileName}.${type}`);
        fs.writeFileSync(filePath, Buffer.from(data));
        return { success: true, path: filePath };
    } catch (e: any) {
        console.error('Save report failed', e);
        return { success: false, error: e.message };
    }
});

// 3. Simple Key-Value Store
ipcMain.handle('db-set', async (_, { key, value }) => {
    try {
        if (!db) throw new Error("Database not initialized");
        const stmt = db.prepare('INSERT OR REPLACE INTO store (key, value) VALUES (?, ?)');
        stmt.run(key, JSON.stringify(value));
        return { success: true };
    } catch (e: any) {
        return { success: false, error: e.message };
    }
});

ipcMain.handle('db-get', async (_, key) => {
    try {
        if (!db) return { success: true, data: null };
        const row = db.prepare('SELECT value FROM store WHERE key = ?').get(key) as { value: string };
        return { success: true, data: row ? JSON.parse(row.value) : null };
    } catch (e: any) {
        return { success: false, error: e.message };
    }
});

ipcMain.handle('db-delete', async (_, key) => {
    try {
        if (!db) return { success: true };
        db.prepare('DELETE FROM store WHERE key = ?').run(key);
        return { success: true };
    } catch (e: any) {
        return { success: false, error: e.message };
    }
});

// 4. Encrypted Manual Backup
ipcMain.handle('run-backup', async (_, encryptedData) => {
    try {
        if (!appBasePath) throw new Error("App storage not initialized");
        const paths = getAppPaths(appBasePath);
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T');
        const fileName = `backup_${timestamp[0]}_${timestamp[1].slice(0, 8)}.enc`;
        const filePath = path.join(paths.backups, fileName);
        fs.writeFileSync(filePath, encryptedData);
        return { success: true, fileName };
    } catch (e: any) {
        return { success: false, error: e.message };
    }
});

// 5. App Closing
ipcMain.handle('close-app', async () => {
    console.error("IPC 'close-app' WAS CALLED. STACK TRACE:");
    console.trace();
    app.quit();
});

// 6. Machine ID Retrieval
ipcMain.handle('get-machine-id', async () => {
    try {
        try {
            // Primary attempt: wmic
            const output = execSync('wmic csproduct get uuid', { stdio: ['ignore', 'pipe', 'ignore'], encoding: 'utf8' }).toString();
            const lines = output.split(/\r?\n/).filter((line: string) => line.trim() && !line.includes('UUID') && !line.includes('wmic'));
            if (lines.length > 0 && lines[0].trim()) {
                return lines[0].trim();
            }
        } catch (e) {
            // Ignore WMIC failure, fallback to PowerShell
        }

        // Fallback: PowerShell (Modern Windows 11)
        const psOutput = execSync('powershell.exe -NoProfile -Command "(Get-CimInstance -Class Win32_ComputerSystemProduct).UUID"', { stdio: ['ignore', 'pipe', 'ignore'], encoding: 'utf8' }).toString();
        if (psOutput && psOutput.trim()) {
            return psOutput.trim();
        }

        return 'UNKNOWN-MACHINE-ID';
    } catch (e) {
        console.error('Failed to get machine ID:', e);
        return 'UNKNOWN-MACHINE-ID';
    }
});

// 7. API Fetch to bypass CORS
ipcMain.handle('api-fetch', async (_, url: string, options: any) => {
    try {
        const response = await net.fetch(url, options);
        const data = await response.text();
        try {
            return JSON.parse(data);
        } catch {
            return data;
        }
    } catch (e: any) {
        console.error('API Fetch Failed:', e);
        throw e;
    }
});

// 8. Dynamic Folder Detection
ipcMain.handle('find-bpp-app', async () => {
    try {
        const potentialRoots: string[] = [];

        // 1. Get all logical drives on Windows
        try {
            const output = execSync('wmic logicaldisk get name', { encoding: 'utf8' });
            const drives = output.split(/\r?\n/)
                .filter(line => line.trim() && line.includes(':'))
                .map(line => line.trim());

            drives.forEach(drive => {
                potentialRoots.push(path.join(drive, 'BPP_APP'));
                potentialRoots.push(path.join(drive, 'BPP', 'BPP_APP')); // Check subfolder too
            });
        } catch (e) {
            // Fallback if WMIC fails
            ['C:', 'D:', 'E:', 'F:', 'G:', 'H:'].forEach(d => {
                potentialRoots.push(path.join(d, '/', 'BPP_APP'));
            });
        }

        // 2. Add User Home
        potentialRoots.push(path.join(app.getPath('home'), 'BPP_APP'));

        // 3. Scan for first existing one
        for (const p of potentialRoots) {
            if (fs.existsSync(p)) {
                // Verify it's actually our app directory (contains BharatPP or active_db.sqlite)
                const dataPath = path.join(p, 'BharatPP', 'Data', 'active_db.sqlite');
                if (fs.existsSync(dataPath)) {
                    console.log('🔍 Dynamic Detection: Found BPP_APP at', p);
                    return { success: true, path: p };
                }
            }
        }

        return { success: false, error: 'BPP_APP folder not found' };
    } catch (e: any) {
        return { success: false, error: e.message };
    }
});

// ── 9. SMART AUTO-UPDATE HANDLERS ──

const INSTALLER_NAME = 'bpp_installer.exe';
const getInstallerPath = () => path.join(os.tmpdir(), INSTALLER_NAME);

ipcMain.handle('start-update-download', async (_, downloadUrl: string) => {
    return new Promise((resolve) => {
        try {
            const dest = getInstallerPath();
            const file = fs.createWriteStream(dest);

            https.get(downloadUrl, (response: any) => {
                response.pipe(file);
                file.on('finish', () => {
                    file.close();
                    console.log('✅ Update downloaded to:', dest);
                    resolve({ success: true, path: dest });
                });
            }).on('error', (err: any) => {
                fs.unlink(dest, () => { });
                console.error('❌ Update download failed:', err);
                resolve({ success: false, error: err.message });
            });
        } catch (e: any) {
            resolve({ success: false, error: e.message });
        }
    });
});

ipcMain.handle('backup-and-install', async () => {
    try {
        if (!appBasePath) throw new Error("App storage not initialized");
        const paths = getAppPaths(appBasePath);
        const snapshotDir = path.join(paths.backups, 'PRE_UPDATE_SNAPSHOT');

        if (!fs.existsSync(snapshotDir)) fs.mkdirSync(snapshotDir, { recursive: true });

        // 1. Close DB Connection
        if (db) {
            db.close();
            db = null;
        }

        // 2. Snapshot Data
        const dbFile = path.join(paths.data, 'active_db.sqlite');
        if (fs.existsSync(dbFile)) {
            fs.copyFileSync(dbFile, path.join(snapshotDir, 'active_db_snapshot.sqlite'));
        }
        if (fs.existsSync(CONFIG_PATH)) {
            fs.copyFileSync(CONFIG_PATH, path.join(snapshotDir, 'app-config_snapshot.json'));
        }

        console.log('📦 Data snapshot created in:', snapshotDir);

        // 3. Launch Installer
        const installerPath = getInstallerPath();
        if (!fs.existsSync(installerPath)) throw new Error("Installer file not found");

        console.log('🚀 Launching update installer...');

        // Use spawn to launch detached so we can quit Electron immediately
        const child = spawn(installerPath, [], {
            detached: true,
            stdio: 'ignore'
        });
        child.unref();

        app.quit();
        return { success: true };
    } catch (e: any) {
        console.error('❌ Pre-update backup or install failed:', e);
        // Attempt to re-init DB if failed
        if (appBasePath && !db) initializeDatabase(appBasePath);
        return { success: false, error: e.message };
    }
});

function cleanupOldInstallers() {
    try {
        const dest = getInstallerPath();
        if (fs.existsSync(dest)) {
            // Check if it's been there for more than a few minutes (avoid deleting during active download)
            const stats = fs.statSync(dest);
            const ageMinutes = (Date.now() - stats.mtimeMs) / (1000 * 60);
            if (ageMinutes > 5) {
                fs.unlinkSync(dest);
                console.log('🧹 Cleaned up old installer file.');
            }
        }

        // Also check if there are any orphaned EXEs in the app root
        if (appBasePath) {
            const rootFiles = fs.readdirSync(appBasePath);
            rootFiles.forEach((file: string) => {
                if (file.toLowerCase().endsWith('.exe') && file.toLowerCase().includes('bpp_app')) {
                    // This might be an old version left behind. 
                    // We don't delete immediately to be safe, but we log it.
                    console.log(`ℹ️ Found potential legacy EXE in root: ${file}`);
                }
            });
        }
    } catch (e) {
        console.warn('⚠️ Cleanup check skipped:', e);
    }
}

console.log("-----------------------------------------");
console.log("ELECTRON MAIN PROCESS: HANDLERS READY");
console.log("-----------------------------------------");
